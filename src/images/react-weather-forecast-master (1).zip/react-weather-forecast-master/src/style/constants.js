export default {
    menuHeight: "64px",
    menuHeightSlim: "42px",
    systemColor: "#fff",
    xs: "599px",
    sm: "959px",
    md: "1279px",
    lg: "1699px"
    //ff: " \"Segoe UI Web (Cyrillic)\", \"Segoe UI\", -apple-system, BlinkMacSystemFont, Roboto, \"Helvetica Neue\", sans-serif"
}