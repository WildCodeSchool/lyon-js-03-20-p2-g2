import React from 'react';
import Menu from './MainMenu.jsx';

const MainPage = () => <Menu />;

export default MainPage;